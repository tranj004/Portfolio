window.onscroll = function () {
    myFunction();
    tecskills();
    sofskills();
    fade();
};

var navbar = document.getElementById("mainNav");
var affix = navbar.offsetTop;

function myFunction() {
    if (window.pageYOffset >= affix) {
        navbar.classList.add("affix");
    } else {
        navbar.classList.remove("affix");
    }
}

var skill = document.getElementById("skills");
const tskills = document.querySelectorAll(".tskill");
var ofTop = skill.offsetTop;

function tecskills() {
    if ((window.pageYOffset + 300) >= ofTop) {
        tskills.forEach(tskill => {
            tskill.classList.add("animateT")
        });
    } else {
        tskills.forEach(tskill => {
            tskill.classList.remove("animateT")
        });
    }
}

const sskills = document.querySelectorAll(".sbskill");

function sofskills() {
    if ((window.pageYOffset + 300) >= ofTop) {
        sskills.forEach(sskill => {
            sskill.classList.add("animateS")
        });
    } else {
        sskills.forEach(sskill => {
            sskill.classList.remove("animateS")
        });
    }
}

var exper = document.getElementById("experience");
const timeline = document.querySelectorAll(".timeline-content");
var ofTop2 = exper.offsetTop;

function fade() {
    if ((window.pageYOffset + 300) >= ofTop2) {
        timeline.forEach(time => {
            time.classList.add("fade")
        });
    } else {
        timeline.forEach(time => {
            time.classList.remove("fade")
        });
    }
}
